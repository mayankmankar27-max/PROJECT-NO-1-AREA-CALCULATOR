#include <stdio.h>

int main() {
    int choice;
    float radius, length, width, base, height, area;

    printf("AREA CALCULATOR\n");
    printf("1. Circle\n");
    printf("2. Rectangle\n");
    printf("3. Triangle\n");

    printf("Enter your choice: ");
    scanf("%d", &choice);

    if (choice == 1) {
        printf("Enter radius: ");
        scanf("%f", &radius);

        area = 3.14 * radius * radius;
        printf("Area of Circle = %.2f", area);
    }
    else if (choice == 2) {
        printf("Enter length: ");
        scanf("%f", &length);

        printf("Enter width: ");
        scanf("%f", &width);

        area = length * width;
        printf("Area of Rectangle = %.2f", area);
    }
    else if (choice == 3) {
        printf("Enter base: ");
        scanf("%f", &base);

        printf("Enter height: ");
        scanf("%f", &height);

        area = 0.5 * base * height;
        printf("Area of Triangle = %.2f", area);
    }
    else {
        printf("Invalid choice!");
    }

    return 0;
}